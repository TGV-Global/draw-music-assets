# Clean Assets Catalog - Draw Music

Thư mục này chứa toàn bộ tài nguyên sạch và hữu ích được chọn lọc từ `assets/` để phục vụ phát triển ứng dụng **Draw Music**. Toàn bộ các file rác, SDK quảng cáo và tệp nhị phân thừa từ APK cũ đã được loại bỏ.

## Cấu Trúc Tài Nguyên Đã Giữ Lại (`asset_clean/`)

1. **`instrument_color_map.json`** (164 KB):
   - Danh mục 274 nhạc cụ chia làm 17 nhóm.
   - Định nghĩa mã màu Hex nét vẽ, bank/program MIDI, và phân loại pack (`core` vs `full`).
2. **`instrument_icon_bounds.json`** (21 KB):
   - Bảng tọa độ bounding box của các icon chuẩn 96x96 px phục vụ căn giữa quang học (optical centering).
3. **`soundfonts/`**:
   - `core.sf2` (~2.0 MB): SoundFont tích hợp sẵn 17 nhạc cụ cơ bản chơi offline.
   - `segmented_manifest.json`: Manifest định nghĩa tải phân đoạn cho gói full soundfont.
4. **`sample_projects/`** (78 file JSON):
   - 78 bài nhạc/tranh vẽ mẫu có sẵn (`cat.json`, `beat_1.json`, `dino.json`, ...) cho Home Screen.
5. **`background/`** (15 file PNG):
   - Hình nền canvas vẽ tranh (`bg_1.png` - `bg_15.png`).
6. **`fonts/`** (13 file font TTF/OTF):
   - Bộ font UI chữ đẹp: Inter, Rubik, SVN-Gilroy, TiltWarp.

---

## Danh Sách Các Tệp Đã Loại Bỏ (Không đưa vào `asset_clean`)

Toàn bộ các tệp/thư mục rác thuộc SDK quảng cáo cũ và runtime APK đã bị lược bỏ:
- `audience_network/` (Classes.dex ~5.5 MB của Meta Ads)
- `ad-viewer/` (Open Measurement JS)
- `dexopt/` (Android ART runtime profile cũ)
- Các tệp MRAID & Ads script: `mraid.js`, `mraid-bridge.js`, `com.moloco...`, `fyb_*.html`, `ia_mraid_bridge.txt`, `ia_js_load_monitor.txt`
- Các tệp XML/JSON rác: `mbridge_download_dialog_view.xml`, `rv_binddatas.xml`, `builddatas.json`, `dic`, `favicon.ico`
