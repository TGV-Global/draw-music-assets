# Draw Music — data chuẩn hóa

Upload **nội dung folder `normalized`** lên thư mục gốc của repo data (hoặc một thư mục con cố định). Không cần upload `data` gốc hay `_normalization`.

Gói này chuẩn bị cho app dùng 13 nhạc cụ engine hiện tại. Chưa thay đổi code, Firebase hoặc URL data của app. Upload xong cần nối app với URL raw/CDN thực tế và kiểm tra từng flow trước khi phát hành.

## Danh mục

| File / thư mục | Nội dung |
|---|---|
| `dataset_manifest.json` | Phiên bản, danh sách file, dung lượng và SHA-256 |
| `sample_projects.json` | 127 template, đường dẫn project/thumbnail và metadata |
| `sample_projects/` | 127 file bản vẽ; giữ nguyên nét vẽ, âm thanh, beat và tọa độ |
| `thumbnails/` | 127 ảnh xem trước, gồm ảnh gốc và ảnh dựng từ nét vẽ |
| `sample_projects_categories.json` | 6 danh mục, giữ bản dịch đã cung cấp |
| `backgrounds.json`, `background/` | 25 background: 15 PNG và 10 WebP |
| `instruments.json` | 13 nhạc cụ; ID, màu và MIDI program từ engine hiện tại |
| `musical_keys.json` | 12 key |
| `wave_tracks.json` | 9 track; có `targetId` để nối enum/state hiện tại |
| `musical_scales.json` | 11 scale; có `targetId` và intervals |
| `content_access_policy.json` | Nguồn phân loại FREE / REWARDED / PREMIUM |
| `id_aliases.json` | ID remote cũ, UUID bản vẽ cũ và ID scale tương ứng |
| `loading.json` | Animation loading được cung cấp |

## Phân loại

| Nhóm | FREE | REWARDED | PREMIUM |
|---|---:|---:|---:|
| Template | 39 | 42 | 46 |
| Nhạc cụ | 4 | 5 | 4 |
| Key | 8 | 4 | 0 |
| Wave | 3 | 4 | 2 |
| Scale | 3 | 5 | 3 |

Nhạc cụ Free: SOFT_KEY, MARIMBA, WARM_SYNTH, BELLS.

Nhạc cụ Reward: PLUCK, FLUTE, STRINGS, CHIME, BASS.

Nhạc cụ Premium: EIGHT_BIT, ELECTRONIC_BASS, GUITAR, SAXOPHONE.

Blues và Chromatic là REWARDED. Beat 1, Beat 2, Beat 3 là PREMIUM.

78 template cổ điển lấy tier từ `asset_draw/content_access_policy.json` đã cung cấp, đối chiếu tên file và UUID của bản `asset_draw`. 49 template mới lấy tier từ metadata local; 29 mục thiếu trong metadata local được bổ sung bằng snapshot Firebase đã kiểm kê ở bước 1. Do đó **57 template có tier khác JSON local cũ**. Báo cáo đối chiếu đầy đủ nằm ngoài gói upload, tại `_normalization/normalization_report.json`.

## Hợp đồng tích hợp

- Tất cả đường dẫn là tương đối với folder này; không chứa ổ đĩa Windows hoặc URL repo giả định. `baseUrl: null` có nghĩa URL triển khai chưa được gắn. App cấu hình URL sau khi repo được upload.
- `id`, `slug` trong catalog và `id` trong project thống nhất theo slug. UUID bản gốc giữ trong `id_aliases.json`, phục vụ đối chiếu/migration ở bước tích hợp. Bản vẽ chỉ đổi ID và tiêu đề; không remap nhạc cụ hoặc nét vẽ sang hệ SF_*.
- Alias `kapi_01` → `kabi_01`, `frog_2` → `frog_02`. App cần phân giải alias trước khi tìm template/policy và xem xét quyền đã lưu theo ID cũ.
- UUID gốc `722ff13b-8705-45dc-9c60-26a10fa208b4` xuất hiện ở cả `canhcut_01` và `wizard_boy`. Đã tách vào `ambiguousOriginalDocuments`, không tự ánh xạ một UUID sang hai quyền. Khi migrate, cần slug hoặc đường dẫn cũ để phân biệt; không tự cấp quyền cho cả hai.
- Policy key: `template:<slug>`, `instrument:<enum hiện tại>`, `key:C_SHARP`, `wave:DRUM_KIT`, `scale:MAJOR_PENTATONIC`. Scale PENTATONIC trong engine tương ứng MAJOR_PENTATONIC trong policy.
- Tất cả 172 mục đã có policy cụ thể. `defaults` giữ cấu trúc schema v1; reader phải kiểm tra mục nằm trong danh mục hợp lệ trước khi dùng defaults. Khi thêm nội dung, bổ sung policy và kiểm tra lại; không tự xuất bản mục thiếu tier.
- `policyVersion: 2`, `grantRevision: 1`. Chưa migrate entitlement của app; bước tích hợp cần giữ các quyền cũ hợp lệ, không tự thu hồi vì đổi ID.
- Policy là nguồn chính. `premium`, `reward`, `is_vip` ở catalog template chỉ là các cờ tương thích và đã đồng bộ theo policy; không tự phân loại theo thứ tự hoặc modulo.
- FREE template: interstitial trước khi mở. REWARDED: mở đúng mục sau khi nhận thưởng hợp lệ; lần mở đầu không kèm interstitial tiếp. Lần dùng sau xử lý như Free. PREMIUM: mở IAP. Người có Premium mở toàn bộ và không có ads. Các quy tắc thực thi này sẽ được nối ở bước app riêng.
- Dùng cache hợp lệ khi offline/fetch lỗi; kiểm tra SHA-256 và đường dẫn trước khi thay cache. Manifest không hash chính nó để tránh tham chiếu vòng.

Không đưa metadata macOS, script chuyển đổi cũ, thư mục trùng, bộ 274 nhạc cụ SF hoặc SF2 vào gói runtime của engine 13 nhạc cụ. Các file đầu vào vẫn giữ nguyên ở thư mục data gốc.
