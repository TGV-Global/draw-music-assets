# Draw Music Data Repository

Remote data repository for Draw Music Android application.

## Contents
- sample_projects/: 78 sample drawing music project templates.
- ackground/: 15 canvas background textures.
- sample_projects.json: Metadata catalog of sample projects.
- ackgrounds.json: Metadata catalog of background assets.
