from pathlib import Path
from PIL import Image

input_dir = Path(r"D:\PTMH\draw_music_data\sample_projects_v1\thumbnail")

files = [
    file
    for pattern in ("*.png", "*.jpg", "*.jpeg")
    for file in input_dir.glob(pattern)
]

print(f"Found {len(files)} image files")

for image_file in files:
    webp_file = image_file.with_suffix(".webp")

    try:
        with Image.open(image_file) as img:
            img.save(webp_file, "WEBP", quality=90, method=6)

        image_file.unlink()

        print(f"Converted & deleted: {image_file.name} -> {webp_file.name}")

    except Exception as e:
        print(f"Error converting {image_file.name}: {e}")

print("Done!")