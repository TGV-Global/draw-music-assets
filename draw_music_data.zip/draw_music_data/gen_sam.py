import json
from pathlib import Path

BASE_DIR = Path(r"D:\PTMH\draw_music_data\sample_projects_v1")
THUMB_DIR = BASE_DIR / "thumbnail"
OUTPUT_FILE = BASE_DIR / "art_items.json"

DEFAULT_SOUND = "SOFT_KEY"
DEFAULT_BPM = 120
DEFAULT_SCALE = "PENTATONIC"

TITLE_OVERRIDES = {
    "canhcut": "Penguin",
    "cartoon": "Cartoon",
    "cat": "Cat",
    "cow": "Cow",
    "crab": "Crab",
    "dog": "Dog",
    "duck": "Duck",
    "flower": "Flower",
    "ghost": "Ghost",
    "girl": "Girl",
    "horse": "Horse",
    "kabi": "Kabi",
    "moon": "Moon",
    "music": "Music",
    "shark": "Shark",
}

items = []

for json_file in sorted(BASE_DIR.glob("*.json")):
    if json_file.name == OUTPUT_FILE.name:
        continue

    slug = json_file.stem
    prefix = slug.rsplit("_", 1)[0]

    try:
        with json_file.open("r", encoding="utf-8") as f:
            project_data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        print(f"Skip {json_file.name}: {e}")
        continue

    thumbnail_name = f"thumb_{slug}.webp"
    thumbnail_file = THUMB_DIR / thumbnail_name

    thumbnail = (
        f"sample_projects_v1/thumbnail/{thumbnail_name}"
        if thumbnail_file.exists()
        else None
    )

    if thumbnail is None:
        print(f"Missing thumbnail: {thumbnail_name}")

    item = {
        "id": slug,
        "slug": slug,
        "title": TITLE_OVERRIDES.get(
            prefix,
            prefix.replace("_", " ").title()
        ),
        "path": f"sample_projects/{json_file.name}",
        "sound": DEFAULT_SOUND,
        "bpm": DEFAULT_BPM,
        "scale": DEFAULT_SCALE,
        "stroke_count": project_data.get("stroke_count", 0),
        "thumbnail": thumbnail,
        "is_vip": False,
        "category": "nature",
        "premium": False,
        "reward": False,
    }

    items.append(item)

with OUTPUT_FILE.open("w", encoding="utf-8") as f:
    json.dump(items, f, ensure_ascii=False, indent=2)

print(f"Created: {OUTPUT_FILE}")
print(f"Total items: {len(items)}")